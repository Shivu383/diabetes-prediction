from django.urls import path
from detection.views import index, register, login, diagnosis, diseasepredict

urlpatterns = [
    path('', index, name='index'),
    path('diagnosis/', diagnosis, name='diagnosis'),
    path('register/', register, name='register'),
    path('login/', login, name='login'),
    path('diseasepredict/', diseasepredict, name='diseasepredict'),
]