from django.shortcuts import render
from django.http import JsonResponse
from .models import UserProfile
from django.contrib.auth import authenticate, login
import pandas as pd
import pickle
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier 
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import RobustScaler
import random
from sklearn.model_selection import train_test_split
from sklearn import metrics
import matplotlib.pyplot as plt
import os

#Load Decision Tree Model
trained_dt_model = pickle.load(open('C:\\Users\\Lenovo\\diabeties_detection (1)\\diabeties_detection\\Training\\trained_dt_model.pkl', 'rb'))
# Load KNN model
trained_knn_model = pickle.load(open('C:\\Users\\Lenovo\\diabeties_detection (1)\\diabeties_detection\\Training\\trained_knn_model.pkl', 'rb'))
# Load Random Forest model
trained_rf_model = pickle.load(open('C:\\Users\\Lenovo\\diabeties_detection (1)\\diabeties_detection\\Training\\trained_rf_model.pkl', 'rb'))
# Load Logistic Regression model
trained_lr_model = pickle.load(open('C:\\Users\\Lenovo\\diabeties_detection (1)\\diabeties_detection\\Training\\trained_lr_model.pkl', 'rb'))
# Load Gradient Boosting model
trained_gb_model = pickle.load(open('C:\\Users\\Lenovo\\diabeties_detection (1)\\diabeties_detection\\Training\\trained_gb_model.pkl', 'rb'))
#dataload
data = pd.read_csv('C:\\Users\\Lenovo\\diabeties_detection (1)\\diabeties_detection\\Data\\diabetes.csv')


# create the scaler
scaler = RobustScaler()


def index(request):
    return render(request, 'detection/index.html')

def diagnosis(request):
    return render(request, 'detection/diagnosis.html')

def accuracy(score):
    val = 90 - score
    return '{:.2f}'.format(val)

def login(request):
    if request.method == 'POST':
        signphone = request.POST.get('signphone')
        signpassword = request.POST.get('signpassword')

        user = UserProfile.objects.filter(phone=signphone).first()

        if user is not None:
            if signpassword == user.password:
                return JsonResponse({'status': 'success', 'output': '1'})
            else:
                return JsonResponse({'status': 'error', 'output': '0'})
        else:
            return JsonResponse({'status': 'error', 'output': '0'})
    return JsonResponse({'status': 'error', 'output': '0'})

def register(request):
    if request.method == 'POST':
        regusername = request.POST.get('regusername')
        regphone = request.POST.get('regphone')
        regemail = request.POST.get('regemail')
        regpassword = request.POST.get('regpassword')
        regaddress = request.POST.get('regaddress')
        regage = request.POST.get('regage')
        reggender = request.POST.get('reggender')

        try:
            UserProfile.objects.create(
                username=regusername,
                phone=regphone,
                email=regemail,
                password=regpassword,
                address=regaddress,
                age=regage,
                gender=reggender
            )
            return JsonResponse({'status': 'success', 'output': 1})
        except Exception as e:
            return JsonResponse({'status': 'error', 'error_message': str(e), 'output': 0})
    return JsonResponse({'status': 'error', 'error_message': 'Invalid request method', 'output': 0})

def diseasepredict(request):
    if request.method == 'POST':

        pregnancies  = int(request.POST.get('pregnancies'))
        glucose      = int(request.POST.get('glucose'))
        bp           = int(request.POST.get('bp'))
        skinthick    = int(request.POST.get('skinthick'))
        insulin      = int(request.POST.get('insulin'))
        bmi          = float(request.POST.get('bmi'))
        pedigree     = float(request.POST.get('pedigree'))
        age          = int(request.POST.get('age'))

        train_data, test_data = train_test_split(data, test_size=0.25, random_state=0)

        # separate the data from the labels
        X_train, y_train = train_data.drop(columns=["Outcome"], axis=1), train_data["Outcome"]
        X_test, y_test = test_data.drop(columns=["Outcome"], axis=1), test_data["Outcome"]

        # rand_suf = random.randint(40, 50)
        # random_data = data.sample(n=min(1000, len(data)), replace=False, random_state= rand_suf)

        # fit the scaler and transform our data
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

        # X = random_data.drop(columns=['Outcome'])
        # y = random_data['Outcome']

        # print(X)
        # X = X.iloc[1:]
        # y = y.iloc[1:]
        # Initialize a dictionary to hold the accuracies

        accuracies = {}

        n_estimators = random.randint(1, 10)
        max_depth = random.randint(1, 10)
        class_weight1 = random.randint(1, 10)
        class_weight2 = random.randint(1, 10)
        # DT
        clf = DecisionTreeClassifier(criterion='gini', max_depth=max_depth, min_samples_split=2, min_samples_leaf=1, max_features=None, class_weight={0: class_weight1, 1: class_weight2})  # Set a maximum depth for pruning
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        dt_accuracy =  metrics.accuracy_score(y_test, y_pred)
        accuracies['DT'] = "{:.2f}".format(dt_accuracy * 100)

        #RF
        rf = RandomForestClassifier(n_estimators = n_estimators, max_depth=max_depth)
        rf = rf.fit(X_train,y_train)
        y_pred = rf.predict(X_test)
        rf_accuracy =  metrics.accuracy_score(y_test, y_pred)
        accuracies['RF'] = "{:.2f}".format(rf_accuracy * 100)

        #KNN
        knn = KNeighborsClassifier() 
        knn.fit(X_train, y_train)
        y_pred_knn=knn.predict(X_test)
        knn_accuracy = metrics.accuracy_score(y_test, y_pred_knn)
        accuracies['KNN'] = "{:.2f}".format(knn_accuracy * 100)

        gb = GradientBoostingClassifier(learning_rate=0.1)
        gb.fit(X_train, y_train)
        y_pred_gb=gb.predict(X_test)
        gb_accuracy = metrics.accuracy_score(y_test, y_pred_gb)
        accuracies['GB'] = "{:.2f}".format(gb_accuracy * 100)

        # lr = LogisticRegression(max_iter=40)
        # lr.fit(X_train, y_train)
        # y_pred_lr = lr.predict(X_test)
        # lr_accuracy = metrics.accuracy_score(y_test, y_pred_lr)
        # accuracies['LR'] = "{:.2f}".format(lr_accuracy * 100)

        # Find the model with the highest accuracy
        best_model = max(accuracies, key=accuracies.get)
        greater_accuracy = accuracies[best_model]

        input_variables = pd.DataFrame([[pregnancies, glucose, bp, skinthick, insulin, bmi, pedigree, age]], columns=['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age'], dtype=float)

        # Make prediction using the best model
        if best_model == 'DT':
            final_prediction = clf.predict(input_variables)[0]
            bm = 'Decision Tree'
        elif best_model == 'RF':
            final_prediction = rf.predict(input_variables)[0]
            bm = 'Random Forest'
        elif best_model == 'KNN':
            final_prediction = knn.predict(input_variables)[0]
            bm = 'K Nearest Neighbour'
        elif best_model == 'GB':
            final_prediction = gb.predict(input_variables)[0]
            bm = 'Gradient Boosting'
        # elif best_model == 'LR':
        #     final_prediction = lr.predict(input_variables)[0]
        #     bm = 'Logistic Regression'

        # Plotting
        plt.figure(figsize=(10, 6))
        classifiers = list(accuracies.keys())
        accuracies_values = [float(accuracy) for accuracy in accuracies.values()]

        plt.bar(classifiers, accuracies_values, color=['blue', 'green', 'orange', 'red'])
        plt.xlabel('Classifier')
        plt.ylabel('Accuracy (%)')
        plt.title('Comparison of Classifier Accuracies')
        plt.ylim(0, 100)  # Set y-axis limit from 0 to 100
        plt.grid(axis='y')

        # Save the plot
        plot_path = os.path.join(os.getcwd(), 'detection\\static\\detection\\', 'metric.jpg')
        plt.savefig(plot_path)
        
        return JsonResponse({'status': 'success', 'output': str(final_prediction), 'compare':accuracies, 'best':bm})
    else:
        return JsonResponse({'status': 'success', 'output': 'error'})