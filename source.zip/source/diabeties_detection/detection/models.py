# models.py

from django.db import models

class UserProfile(models.Model):
    username = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    password = models.CharField(max_length=100)
    address = models.CharField(max_length=255)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)

    class Meta:
        # Optional meta options
        app_label = 'detection'
